<?php
class ExpiredException extends \UnexpectedValueException
{

}
