        </div>
        </div>
        </div>

        <?php
        if (!isset($grocery)) { ?>
                <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
                <script src="<?php echo base_url('assets/js/popper.js'); ?>"></script>
        <?php } ?>
        
        <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/main.js'); ?>"></script>
        <script src="<?php echo base_url('assets/js/myContact.js'); ?>"></script>

        </body>

        </html>