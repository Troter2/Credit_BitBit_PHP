<div class="container ">
  <p>AL DARLE AL BOTÓN QUE TE LLEVE A LA PAGINA DE CREACIÓN DE TASK AUNQUE ESTA PODRÍA SER LA PROPIA PAGINA DE DETALLES</p>
  <div class="row ">
    <div class="col text-center">
      <a href="<?php echo base_url('/details') ?>">
        <input href="<?php echo base_url('/details') ?>" class="btn btn-primary btn-lg" type="button" value="ADD Task">
      </a>
    </div>
  </div>
</div>